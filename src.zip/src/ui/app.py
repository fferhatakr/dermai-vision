import streamlit as st
import requests
from PIL import Image
import io
import base64
import cv2
import numpy as np
import os

# Define the backend API endpoint
API_BASE = "http://127.0.0.1:8000"

# Configure the page layout for cross-device compatibility 
# 'centered' ensures it reads like an app on mobile and avoids extreme stretching on desktop
st.set_page_config(page_title="DermaScan AI", layout="centered")

# Inject custom CSS for a polished, modern UI
# Added slight shadows and rounded corners to images for a professional medical app feel
st.markdown("""
    <style>
    .main { background-color: #0e1117; }
    img { border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.3); }
    .stProgress > div > div > div > div { background-image: linear-gradient(to right, #4facfe 0%, #00f2fe 100%); }
    div[data-testid="stExpander"] { border: 1px solid #30363d; border-radius: 8px; }
    .block-container { padding-top: 2rem; padding-bottom: 2rem; }
    </style>
    """, unsafe_allow_html=True)

# Initialize session state variables for authentication tracking
if "token" not in st.session_state:
    st.session_state.token = None
if "user_email" not in st.session_state:
    st.session_state.user_email = None

# ----------------------------------------------------------------------------
# AUTHENTICATION MODULE
# Renders the Sign In and Registration forms if the user is not authenticated.
# ----------------------------------------------------------------------------
if st.session_state.token is None:
    st.title("DermaScan AI")
    st.markdown("---")

    # Use tabs to separate login and registration views cleanly
    tab_login, tab_register = st.tabs(["Sign In", "Create Account"])

    # Login Logic
    with tab_login:
        with st.container():
            email = st.text_input("Email", key="login_email")
            password = st.text_input("Password", type="password", key="login_pass")

            # use_container_width makes the button span the full width, which is much better for mobile tapping
            if st.button("Sign In", type="primary", use_container_width=True):
                if email and password:
                    try:
                        r = requests.post(f"{API_BASE}/users/login",
                                          json={"email": email, "password": password})
                        if r.status_code == 200:
                            st.session_state.token = r.json()["access_token"]
                            st.session_state.user_email = email
                            st.rerun()
                        else:
                            st.error("Invalid email or password.")
                    except Exception as e:
                        st.error(f"Connection error: {e}")
                else:
                    st.warning("Please fill in all fields.")

    # Registration Logic
    with tab_register:
        with st.container():
            full_name = st.text_input("Full Name", key="reg_name")
            reg_email = st.text_input("Email", key="reg_email")
            reg_pass = st.text_input("Password", type="password", key="reg_pass")

            if st.button("Create Account", type="primary", use_container_width=True):
                if full_name and reg_email and reg_pass:
                    try:
                        r = requests.post(f"{API_BASE}/users/register",
                                          json={"email": reg_email, "password": reg_pass,
                                                "full_name": full_name})
                        if r.status_code == 200:
                            st.success("Account created. Please sign in.")
                        else:
                            st.error(r.json().get("detail", "Registration failed."))
                    except Exception as e:
                        st.error(f"Connection error: {e}")
                else:
                    st.warning("Please fill in all fields.")

    # Halt script execution here if the user is not logged in
    st.stop()

# ----------------------------------------------------------------------------
# MAIN DASHBOARD
# Accessible only after successful authentication.
# ----------------------------------------------------------------------------

# Sidebar for user profile display and logout functionality
with st.sidebar:
    st.markdown(f"**User:** {st.session_state.user_email}")
    if st.button("Sign Out", use_container_width=True):
        st.session_state.token = None
        st.session_state.user_email = None
        st.rerun()

# Dashboard Header
st.title("DermaScan AI: Meta-Learning Fusion System")

st.warning("Disclaimer: This application is solely an engineering portfolio project. It is not a medical diagnostic device. Please consult a dermatologist regarding any genuine health concerns.")
st.info("Privacy Policy: Uploaded images are processed strictly in-memory and are never stored. Analysis results and patient records are securely stored in an encrypted PostgreSQL database for clinical follow-up.")
st.markdown("Combined analysis of Deep Learning (CNN) and Clinical Metadata (XGBoost)")
st.markdown("---")

image = None
image_ready = False

# Organize input methods into tabs to save vertical space on mobile devices
tab_input, tab_meta = st.tabs(["Image Upload", "Clinical Data"])

# Image Selection Logic
with tab_input:
    sample_folder = "test_samples"
    samples = os.listdir(sample_folder) if os.path.exists(sample_folder) else []
    selected_sample = st.selectbox("Select a test sample", ["None"] + samples)

    uploaded_file = st.file_uploader("Or Select Dermatoscopic Image", type=["jpg", "png", "jpeg"])

    if uploaded_file:
        image = Image.open(uploaded_file).convert("RGB")
        image_ready = True
        st.image(image, caption="Current Scan", use_container_width=True)
    elif selected_sample != "None":
        image = Image.open(os.path.join(sample_folder, selected_sample)).convert("RGB")
        image_ready = True
        st.image(image, caption=f"Sample: {selected_sample}", use_container_width=True)

# Clinical Metadata Input Logic
with tab_meta:
    full_name = st.text_input("Patient Full Name", placeholder="e.g. John Smith")
    age = st.number_input("Patient Age:", min_value=0, max_value=120, value=30)
    sex = st.selectbox("Gender:", ["male", "female", "unknown"])

    site_options = [
        'anterior torso', 'upper extremity', 'posterior torso',
        'lower extremity', 'flat', 'head/neck', 'palms/soles', 'unknown'
    ]
    anatom_site = st.selectbox("Anatomical Site:", site_options)

    st.info("The Meta-Learner combines these clinical factors with visual patterns for higher accuracy.")

# ----------------------------------------------------------------------------
# ANALYSIS EXECUTION
# Triggers the backend API call, parses JSON, and formats the output UI.
# ----------------------------------------------------------------------------
analyze_btn = st.button("EXECUTE HYBRID ANALYSIS", type="primary", use_container_width=True)

if analyze_btn and image_ready and full_name:
    with st.spinner("Deep Learning & XGBoost Fusion in progress..."):
        try:
            # Convert image to a byte array for HTTP transmission
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format="JPEG")

            files = {"file": ("scan.jpg", img_byte_arr.getvalue(), "image/jpeg")}
            data = {
                "age": str(age),
                "sex": sex,
                "anatom_site": anatom_site,
                "needs_heatmap": "true",
                "full_name": full_name
            }

            # Send data to the backend API securely with JWT token
            response = requests.post(
                f"{API_BASE}/analyze",
                files=files,
                data=data,
                headers={"Authorization": f"Bearer {st.session_state.token}"}
            )

            # Handle unauthorized access (e.g., expired token)
            if response.status_code == 401:
                st.error("Session expired. Please sign in again.")
                st.session_state.token = None
                st.rerun()

            # Handle successful response
            elif response.status_code == 200:
                result = response.json()
                st.divider()

                pred = result["prediction"]
                diag = result["diagnosis"]

                # Display primary diagnostic alerts prominently
                st.subheader("Diagnostic Consensus")
                if pred == "Risky":
                    st.error(f"SYSTEM ALERT: {pred.upper()}")
                    st.markdown(f"**Suspected Diagnosis:** {diag}")
                else:
                    st.success(f"ANALYSIS: {pred.upper()}")
                    st.markdown(f"**Likely Diagnosis:** {diag}")

                st.divider()

                # Hide complex metrics inside an expander for a cleaner initial UI
                with st.expander("Advanced Analysis Metrics (Debug)"):
                    
                    # Columns display side-by-side on Desktop, but auto-stack vertically on Mobile
                    col_cnn, col_meta = st.columns(2)
                    
                    with col_cnn:
                        st.info("VISION ONLY")
                        st.markdown(f"**Diagnosis:** `{result['debug']['cnn_diagnosis']}`")
                        st.markdown(f"**Confidence:** %{result['debug']['cnn_confidence']*100:.1f}")
                        st.progress(float(result['debug']['cnn_confidence']))

                    with col_meta:
                        st.warning("META-LEARNER")
                        st.markdown(f"**Diagnosis:** `{result['diagnosis']}`")
                        st.markdown(f"**Confidence:** %{result['confidence']*100:.1f}")
                        st.progress(float(result['confidence']))

                    st.markdown("---")
                    if result['debug']['conflict']:
                        st.error(f"CLINICAL CONFLICT: Metadata changed diagnosis from {result['debug']['cnn_diagnosis']} to {result['diagnosis']}.")
                    else:
                        st.success("CONSENSUS: Both systems agreed on the diagnosis.")

                # Display differential probabilities using a responsive layout ratio
                if "all_probabilities" in result:
                    st.subheader("Differential Diagnosis")
                    probs = result["all_probabilities"]
                    for disease, score in list(probs.items())[:3]:
                        col_text, col_prog = st.columns([1, 3])
                        with col_text:
                            st.write(f"**{disease}**")
                        with col_prog:
                            st.progress(float(score))

                st.divider()

                # Visual evidence layout: Side-by-side on desktop, stacked on mobile
                st.subheader("Visual Analysis")
                col_orig, col_heat = st.columns(2)
                
                with col_orig:
                    st.markdown("**Original Scan**")
                    st.image(image, use_container_width=True)

                with col_heat:
                    st.markdown("**AI Focus Map (Grad-CAM)**")
                    hm_b64 = result.get("heatmap_base64", "")
                    if hm_b64:
                        # Decode the base64 heatmap from the backend and overlay it on the original image
                        decoded = base64.b64decode(hm_b64)
                        np_arr = np.frombuffer(decoded, np.uint8)
                        hm_img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                        hm_img = cv2.cvtColor(hm_img, cv2.COLOR_BGR2RGB)
                        orig_cv = np.array(image)
                        
                        # Ensure heatmap dimensions strictly match the original image
                        hm_img = cv2.resize(hm_img, (orig_cv.shape[1], orig_cv.shape[0]))
                        
                        # Blend the original image and the heatmap together
                        overlay = cv2.addWeighted(orig_cv, 0.6, hm_img, 0.4, 0)
                        st.image(overlay, use_container_width=True, caption="Heatmap: Blue (Safe) -> Red (Suspicious)")
                    else:
                        st.warning("Heatmap could not be generated for this scan.")

            else:
                st.error(f"Backend Error: {response.text}")

        except Exception as e:
            st.error(f"Connection Failed: {e}")

elif analyze_btn and not image_ready:
    st.warning("Please select or upload an image first.")